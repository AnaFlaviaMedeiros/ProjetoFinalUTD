<?php
	//pasta do projeto
	$project_name = "/projeto";
	
	//rota de url
	$project_index = "http://".$_SERVER['SERVER_NAME'].$project_name; // http://localhost/projeto

	//rota do diretorio
	$project_path = $_SERVER['DOCUMENT_ROOT'].$project_name; //onde esta o projeto.

	//variaveis globais(para uso nas funções)
	$GLOBALS['index'] = $project_index;
	$GLOBALS['path'] = $project_path;

?>