<?php

 	include_once'models/config.php';
 	include_once'controller/validate.php';

 	//Função de conteudo da pagina
 	function page_content(){
 	 	validade_options();
 	}

 	include_once'views/template.php';
 	
?>