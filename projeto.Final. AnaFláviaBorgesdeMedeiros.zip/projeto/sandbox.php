<?php

	include_once dirname(__DIR__). '/models/classes/Connect.class.php'; 
	include_once dirname(__DIR__). '/models/classes/Maneger.class.php';

/*	$manager = new Maneger;

	//inserindo alguem no banco.
	$data['user_name'] = "Ana Flavia";
	$data['user_name'] = "anaflavia.bd@hotmail.com";
	$data['user_password'] = sha1('271195');

	//echo $manager->insert_commen("tb_users", $data, null);
	/*$todoMundo = $manage ->select_commen("tb_users", null, null, " Order by user_name ");

	print_r($todoMundo);
	*/
	/*
	include_once 'models/config.php';

	echo $project_path."<br>";
	echo $project_index."<br>";
	echo $GLOBALS['index']."<br>";
	echo $GLOBALS['path']."<br>";

	function show(){
		global $project_index;
		global $project_path
		echo "Mostrando...<br>";
		echo "NÃO GLOBAL".$project_path."<br>";  //agr globalizadas
		echo "NÃO GLOBAL".$project_index."<br>"; //agr globalizadas
		echo "GLOBAL".$GLOBALS['index']."<br>";
		echo "GLOBAL".$GLOBALS['path']."<br>";
	}
	*/
?> 
<!--TESTES ??-->