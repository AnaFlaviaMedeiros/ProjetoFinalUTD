<?php

	include_once dirname(__DIR__).'/models/config.php';
    include_once $project_path.'/models/classes/Connect.class.php';
    include_once $project_path.'/models/classes/Manager.class.php';

    //recebendo dados do formulario
    $email = $_POST['email'];
    $pass = $_POST['password'];

    //criar um objeto do tipo manager
    $manager = new Manager;

    //buscar email digitado no banco de dados
    $log = $manager->select_common("tb_users", null, ["user_email" =>  $email ], " limit 1");

    //tratando o login
    if(!$log){
        header("location: $project_index/index.php?masg=user-not-found");

    }else if ($log[0]['user_password'] != sha1($pass)) {
        header("location: $project_index/index.php?msg=password_incorrect");    
    
    }else{ 
        session_start();
        $_SESSION[md5("user_data")] = $log[0];
        header("location: $project_index/index.php");
    }
?>